*********** Sagar Image Slideshow ***********
Plugin Name:Sagar Image Slideshow
Contributors: Sagar Ratnaparkhi
Tags: image, image slideshow
Tested with: Version 2.9.1

*********** Description ***********
This Plugin created using TinySlideshow javascript plugin.

*********** Installation ***********
1. Upload the entire `sagar-image-slideshow` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

3 After installing Sagar Image Slideshow plugin, you have options as add image, edit image and delete image. To add image insert information of related fields such as image title, description. To set category either choose existing one or insert new category name. Please make sure your file directory path is correct, in settings section of Sagar Image Slideshow.

4.please change the file permission of '/wp-content/plugins/sagar-image-slideshow/images' to 777.

5. The main intension of creating this slideshow is to create no of slideshows with different images. In gallery home section of Sagar Image slideshow, under column category you will find code tag (eg. [view_slideshow cat="1"] ). Put this code in your post or page content.    


*********** Frequently Asked Questions ***********
       please feel free to ask me questions at "sagar.ibmr@gmail.com"


