<table width="100%" border="0" cellspacing="4" cellpadding="4">
  <tr>
    <td><h3>Sagar Image Slideshow help</h3></td>
  </tr>
  <tr>
    <td>Installation</td>
  </tr>
   <tr>
    <td><p align="justify">  After installing Sagar Image Slideshow plugin, you have options as add image, edit image and delete image. To add image insert information of related fields such as image title, description. To set category either choose existing one or insert new category name. Please make sure your file directory path is correct, in settings section of Sagar Image Slideshow.</p></td>
  </tr>
  
  <tr>
    <td><p align="justify"> The main intension of creating this slideshow is to create no. of slideshows with different images. In gallery home section of Sagar Image slideshow, under column category you will find code tag (eg. [view_slideshow cat="1"] ). Put this code in your post or page content.    
</p></td>
  </tr>
  <tr><td align="justify"> Images display with resizing large image with width of 400px and height of 300px and thumb image created with width of 100px and height correlate with width</td></tr>
  <tr>
    <td>About Sagar Image Slideshow</td>
  </tr>
  
   <tr>
    <td>
    <table width="100%" border="0" cellspacing="4" cellpadding="4">
   <tr>
    <td width="21%"><strong>TinySlideshow</strong></td></tr>
    <tr>
    <td width="79%">I am really thankful to TinySlideshow to create such a simple and great slideshow component. Here TinySlideshow javascript plugin used to create this wordpress plugin. </td>
  </tr>
  <tr><td>Please feel free to contact me at sagar.ibmr@gmail.com, egarly waiting for feedback.</td>
  </tr>
  <tr>
      <td >&nbsp;</td></tr>
<tr>          <td width="21%"><strong>Thank you Wordpress</strong></td></tr>
</table>

    
    
    
    </td>
  </tr>
  
</table>
